##################################################
##################################################
### Not exported in the NAMESPACE

SWAP.rank <- function(x) {
	return((apply(x,2,rank)));
}



##################################################
##################################################

SWAP.CalculateSignedScore <- function(situation , data1, data2) {

	n <- length(situation);
	m1 <- nrow(data1);
	m2 <- nrow(data2);

	datatied <- SWAP.rank(rbind(data1,data2));
	data1tied <- datatied[1:m1,];
	data2tied <- datatied[(m1+1):(m1+m2),];

	situationV <- as.vector(situation);

	if (length(unique(situationV)) != 2) {
		stop("The situation must contain only exact two different variable.")
	}

	labels <- unique(situationV);

	d <-	.C(
		"CalculateSignedScoreCore",
		as.integer(as.numeric(situationV==labels[1])), as.integer(n),
		as.double(data1tied), as.integer(m1),
		as.double(data2tied), as.integer(m2),
		as.double(matrix(0, m1, m2)),
		as.double(matrix(0, m1, m2)),
		as.double(1),
		as.double(matrix(0, m1, m2)),
		as.double(1),
		as.double(matrix(0, m1, m2)),
		as.double(matrix(0, m1, m2))
		);

	score <- (matrix(d[[7]], nrow=m1))/2;
#	a <- (matrix(d[[7]], nrow=m1));
#     M <- (matrix(d[[8]], nrow=1));
#	k <- (matrix(d[[9]], nrow=m1));
#	N <- (matrix(d[[10]], nrow=1));
     	P <- (matrix(d[[12]], nrow=m1));
	Q <- (matrix(d[[13]], nrow=m1));

	if (length(rownames(data1))>0 &&  length(rownames(data2))>0 ) {
		names1 <- rownames(data1);
		names2 <- rownames(data2);

		rownames(score) <- names1;
		colnames(score) <- names2;

		rownames(P) <- names1;
		colnames(P) <- names2;

		rownames(Q) <- names1;
		colnames(Q) <- names2;
	}

	retVal <- list(score=score, P=P, Q=Q, labels=labels);

}



##################################################
##################################################

SWAP.CalculateSignedScore.Restricted <- function(situation , data1, data2, pairs) {

	n <- length(situation);
	m1 <- nrow(data1);
	m2 <- nrow(data2);
	pairsno <- nrow(pairs);

	datatied <- SWAP.rank(rbind(data1, data2));
	data1tied <- datatied[1:m1,];
	data2tied <- datatied[(m1+1):(m1+m2),];

	situationV <- as.vector(situation);

	if (length(unique(situationV)) != 2) {
		stop("The situation must contain only exact two different variable.")
	}

	labels <- unique(situationV);


	if (class(pairs[1,1])=="character") {
		pairsind <- matrix(0,pairsno ,2);
		pairsind[,1] <- match(pairs[,1],rownames(data1));
		pairsind[,2] <- match(pairs[,2],rownames(data2));

		if (sum(is.na(pairsind))>0) {
			stop("The genes in pairs do not show in data1 or data2.");
		}
	} else {
		if (min(pairs)<1 || max(pairs[,1])>nrow(data1) || max(pairs[,2])>nrow(data2)) {
			stop("The genes in pairs do not show in data1 or data2.");
		}
		pairsind <- pairs;
	}

	d <-	.C(
		"CalculateSignedScoreRestrictedPairsCore",
		as.integer(as.numeric(situationV==labels[1])),
		as.integer(n),
		as.double(data1tied), as.integer(m1),
		as.double(data2tied), as.integer(m2),
		as.integer(pairsind[,1]-1),
		as.integer(pairsind [,2]-1),
		as.integer(pairsno),
		as.double(matrix(0, pairsno, 1)),
		as.double(matrix(0, pairsno, 1)),
		as.double(matrix(0, pairsno, 1))
		);

	score <- d[[10]]/2;
	P <- d[[11]];
	Q <- d[[12]];

	retVal <- list(score=score, P=P, Q=Q, labels=labels, pairs=pairs);

}



##################################################
##################################################
### KTSP.Train trains the KTSP classifier. 'data' is the matrix of the expression values
### whose columns represents samples and the rows represents the genes.
### 'situation' is a vector containing the training labels. Its elements should be one or zero.
### n is the number of top disjoint pairs.
### If after picking some pairs, only pairs with score left,
### no more pair is chosen even the 'n' has not been reached.

SWAP.KTSP.Train <- function(data, situation, krange= c(3,5:10), RestrictedPairs=c(),
			    Filter=c(), FilterParam=list(UpDown=TRUE, geneNo=100), chooseKDyn=TRUE) {

	if (chooseKDyn) {
		classifiers <- SWAP.KTSP.Train(data, situation, krange, RestrictedPairs, Filter,
					       FilterParam, chooseKDyn=FALSE);
		classifierDynK <- SWAP.ChoooseDynk(data, situation, classifiers, SWAP.KTSP.Statitsics);
		return(classifierDynK);
	} else {

		##Checks whether we should work on gene names or indices
		if (class(rownames(data))=="character") {
			usegenenames <-  TRUE;
		} else {
			usegenenames <- FALSE;
		}

		##Filter gene
		if (length(Filter) > 0) {
			index <- Filter(situation, data, FiltParam=FilterParam);
			if (class(index) == "numeric" && usegenenames==TRUE) {
				index <- rownames(data)[index];
			} else if (class(index) == "character" && usegenenames==FALSE) {
				stop("Filter's output must be numbers if the gene names are not given")
			}
		} else {
			if (usegenenames) {
				index <- rownames(data);
			} else {
				index <- 1:nrow(data);
			}
		}


		if (length(RestrictedPairs)==0) {
			classifiers <- SWAP.KTSP.Train.Plain(data, situation, krange, index);
		} else {
			if (class(RestrictedPairs[1]) != class(index)) {
				stop("RestictedPairs must be coherent with gene names.");
			}
			FilteredPairs <- which(is.element(RestrictedPairs[,1], index)& is.element(RestrictedPairs[,2], index));
			scores <- SWAP.CalculateSignedScore.Restricted(situation, data, data, RestrictedPairs[FilteredPairs,]);
			sortsc <- sort(scores$score, decreasing=TRUE, index= TRUE);
			pairs <- SWAP.KTSP.Pairs.Disjoint(RestrictedPairs[FilteredPairs [sortsc$ix],],
							  sortsc$x,min(max(krange),length(scores)));
			maxTSPs <- length(pairs$scores);
			classifiers <- vector(mode="list",length=length(krange));

			for (i in 1:length(krange)) {
				classifiers[[i]]$name <- sprintf('%dRTSP',krange[i]);
				classifiers[[i]]$TSPs <- pairs$index[1:min(krange[i],maxTSPs),];
				classifiers[[i]]$score <- pairs$scores[1:min(krange[i],maxTSPs),];
			}
		}

		return(classifiers);
	}
}


##################################################
##################################################
### It is the plain kTSP with only genes filtered to the parameter genes
### Example 1:  SWAP.KTSP.Train.Plain(matETABM115, ttmGroupETABM115)
### Example 2:SWAP.KTSP.Train.Plain(matETABM115, ttmGroupETABM115,
###		      genes = rownames(matETABM115)[1:20])


SWAP.KTSP.Train.Plain <- function(data, situation, krange= c(3,5:10), genes=c()) {

	situationV <- as.vector(situation);
	maxK <- max(krange);

	if (length(unique(situationV)) != 2) {
		stop("The situation must contain only exact two different variable.")
	}

	if (length(genes)==0) {
		if (length(rownames(data))==0) {
			genes <- 1:nrow(data);
		} else {
			genes <- rownames(data);
		}
	}

	labels <- unique(situationV);
	KTSPout <- SWAP.CalculateSignedScore(situation , data[genes,], data[genes,]);

	TSPscore <- vector(length=maxK);

	score <- KTSPout$score;
	absscore <- abs(score);

	TSPsInd <- matrix(0, maxK, 2);

	for (i in 1:maxK) {
		nextPair <- arrayInd(which.max(absscore), .dim=dim(score));
		##if the score of the pairs are negligible do not go down the list
		if (absscore[nextPair[1],nextPair[2]] < 1e-4 ) {
			TSPsInd <- TSPsInd[1:i,];
			TSPscore <- TSPscore[1:i];
			break;
		}

		if (score[nextPair[1],nextPair[2]]<0) {
			TSPsInd[i,]= nextPair;
		} else {
			TSPsInd[i,]= c(nextPair[2],nextPair[1]);
		}

		TSPscore[i] <- absscore[TSPsInd[i,1], TSPsInd[i,2]]/2;
		absscore[TSPsInd[i,1],] <- 0;
		absscore[TSPsInd[i,2],] <- 0;
		absscore[,TSPsInd[i,1]] <- 0;
		absscore[,TSPsInd[i,2]] <- 0;
	}

	TSPs <- cbind(genes[TSPsInd[,1]], genes[TSPsInd[,2]]);

	maxTSPs <- nrow(TSPs);
	classifiers <- vector(mode="list", length(krange));

	for (i in 1:length(krange)) {
		classifiers[[i]]$name = sprintf('%dTSP',krange[i]);
		if (min(krange[i],maxTSPs) == 1) {
			classifiers[[i]]$TSPs <- matrix( TSPs[1,], ncol=2, nrow=1)
		} else {
			classifiers[[i]]$TSPs <- TSPs[1:min(krange[i], maxTSPs),];
		}
		classifiers[[i]]$score <- TSPscore[1:min(krange[i], maxTSPs)];
		classifiers[[i]]$labels <- labels;
	}

	return(classifiers);

}


##################################################
##################################################
### It calculates the KTSP statistics : \sum_{k} I(X_i_k <X_j_k) - I(X_j_k <X_i_k)
### statistics = SWAP.KTSP.Statitsics(matETABM115,classifiers)

SWAP.KTSP.Statitsics <- function(data, classifiers) {

	if (length(names(classifiers))>0) {
		##if(length(classifiers$score)>2) {
		if (is.vector(data)) {
			KTSPstat <-
				sum(data[classifiers$TSPs[,1]]>data[classifiers$TSPs[,2]]) -
					sum(data[classifiers$TSPs[,1]]<data[classifiers$TSPs[,2]]);
			KTSPstat <- matrix(KTSPstat, nrow = 1, ncol=1);
			##KTSPstat = matrix(KTSPstat,nrow = 1);
			##Name of the classifier
		} else {
			KTSPstat <-
				apply(data[classifiers$TSPs[,1],]>data[classifiers$TSPs[,2],],2,sum) -
					apply(data[classifiers$TSPs[,1],]<data[classifiers$TSPs[,2],],2,sum);
			KTSPstat <- matrix(KTSPstat,nrow = 1);
		}

		rownames(KTSPstat) <- classifiers$name;
		##} else {
		##KTSPstat <- apply(data[classifiers$TSPs[1],]>data[classifiers$TSPs[2],],2,sum) -
		##	apply(data[classifiers$TSPs[1],]<data[classifiers$TSPs[2],],2,sum);
		##}

	} else {
		if (is.vector(data)) {
			KTSPstat <- matrix( 0, nrow = length(classifiers), ncol = 1);
		} else {
			KTSPstat <- matrix( 0, nrow = length(classifiers), ncol = ncol(data));
		}

		classifiernames <- vector(mode="character",length=length(classifiers));

		for (i in 1:length(classifiers))	{
			## if(length(classifiers[[i]]$score)>2) {

			if (is.vector(data)) {
				KTSPstat[i] <-
					sum(data[classifiers[[i]]$TSPs[,1]]>data[classifiers[[i]]$TSPs[,2]]) -
						sum(data[classifiers[[i]]$TSPs[,1]]<data[classifiers[[i]]$TSPs[,2]]);
			} else {
				KTSPstat[i,] <-
					apply(data[classifiers[[i]]$TSPs[,1],]>data[classifiers[[i]]$TSPs[,2],],2,sum) -
						apply(data[classifiers[[i]]$TSPs[,1],]<data[classifiers[[i]]$TSPs[,2],],2,sum);
			}
			##} else {
			##	KTSPstat[i,] <-
			##		apply(data[classifiers[[i]]$TSPs[,1],]>data[classifiers[[i]]$TSPs[,2],],2,sum) -
			##			apply(data[classifiers[[i]]$TSPs[,1],]<data[classifiers[[i]]$TSPs[,2],],2,sum);
			##}

			classifiernames[i] <- classifiers[[i]]$name;
		}
		rownames(KTSPstat) <- classifiernames;
	}
	return(KTSPstat);
}


##################################################
##################################################
### The classifier for the test data. 'data' is the test data.
### just threshold the outcome of KTSP.Statistics

SWAP.KTSP.Classify <- function(data, classifiers, thresh=0) {

	##Checks if there is only one kTSP or there are multiple of them
	if (length(names(classifiers))>0) {
		mylabels <- classifiers$labels;

		##if (is.vector(data)) {
		##	##if only one classifier and one sample exist
		##	if (ktspStat[i,]>thresh){
		##		pred <- mylabels[1];
		##	} else{
		##		pred = mylabels[2];
		##	}
		##	names(pred) <- classifiers$name;
		##} else {
		##	pred <- vector(mode=class(mylabels[[1]]), ncol(data));
		##	pred[which(ktspStat>thresh)] <- mylabels[1];
		##	pred[which(ktspStat<=thresh)] <- mylabels[2];
		##	##skip the name in the case that there is only one classifier and multiple samples
		##}

		##	} else {
		##		mylabels <- classifiers[[1]]$labels;
		##
		##		if (is.vector(data)) {
		##			pred <- vector(mode=class(mylabels[[1]]),length(classifiers));
		##			classifiernames <- vector(mode="character", length=length(classifiers));
		##			for (i in 1:length(classifiers))	{
		##				pred[which(ktspStat[i,]>thresh)] <- mylabels[1];
		##				pred[which(ktspStat[i,]<=thresh)] <- mylabels[2];
		##				classifiernames[i] <- classifiers[[i]]$name;
		##			}
		##			names(pred) <- classifiernames;
		##		} else {
		##			pred <- matrix(mylabels[1], length(classifiers), ncol(data));
		##			classifiernames <- vector(mode="character", length=length(classifiers));
		##			for (i in 1:length(classifiers))	{
		##				pred[i,which(ktspStat[i,]>thresh)] <- mylabels[1];
		##				pred[i,which(ktspStat[i,]<thresh)] <- mylabels[2];
		##				classifiernames[i] <- classifiers[[i]]$name;
		##			}
		##			rownames(pred) <- classifiernames;
		##		}

	}

		##	#pred <- matrix(mylabels[1], nrow(ktspStat), ncol(ktspStat));
		##	return(pred);

	ktspStat <- SWAP.KTSP.Statitsics(data, classifiers);

	return(ifelse(ktspStat>0, mylabels[[2]], mylabels[[1]]));

}


##################################################
##################################################
### The classifier for the test data. 'data' is the test data.

SWAP.Filter.Wilcoxon <- function(situation, data,
				 FiltParam=list(genesNo=100, UpDown=TRUE) ) {

	tiedData <- SWAP.rank(data);
	tiedDataP <- t(SWAP.rank(t(tiedData)));
	n <- sum(situation==FALSE);
	m <- sum(situation==TRUE);
	sumzeros <- (apply(tiedDataP[,which(situation==situation[1])],1,sum))
	windex <- (sumzeros -n*(n+m+1)/2)/sqrt(n*m*(n+m+1)/12);

	if (FiltParam$UpDown == TRUE) {
		s <- order(windex,decreasing=TRUE);
		lens <- length(s);
		genesIndexUp <- s[1:min(c(round(FiltParam$genesNo/2),lens))];
		genesIndexDown <- s[ max(c(lens-round(FiltParam$genesNo/2),1)):lens];
		genesIndex <- unique(c(genesIndexUp,genesIndexDown));
	} else {
		s <- order(abs(windex),decreasing=TRUE);
		genesIndex <- s[1:min(c(FiltParam$genesNo,length(s)))];
	}

	if (length(rownames(data))==0) {
		return(genesIndex);
	} else {
		return(rownames(data)[genesIndex]);
	}
}


##################################################
##################################################

SWAP.ChoooseDynk <- function(data, situation, classifiers, Discriminant) {

	s0 <- which(situation==0);
	s1 <- which(situation==1);

	##if there is only one classifier, return that classifier
	if (length(names(classifiers))>0) {
		return(classifiers);
	}

	##minimum t-Test
	mintt <- -Inf;
	for (k in 1:length(classifiers)) {
		stat0 <- as.vector(Discriminant( data[,s0], classifiers[[k]]));
		stat1 <- as.vector(Discriminant( data[,s1], classifiers[[k]]));

		##current t-test
		tt <- abs(mean(stat0)-mean(stat1))/sqrt(var(stat1)+var(stat0)+0.000000001);

		##If there is a tie score, we pick the classifier which shows up first
		if (abs(mintt-tt)>0.0000001 && mintt<tt) {
			mintt = tt;
			kmin = k;
		}
	}
	return(classifiers[[kmin]]);

}


##################################################
##################################################
### We may need to write this function in C
### Not yet exported in the NAMESPACE

SWAP.KTSP.Pairs.Disjoint <- function(index, scores, k) {

	sind <- sort(scores, decreasing=TRUE, index=TRUE);
	pairssorted <- index[sind$ix,];
	kTSPs <- pairssorted[1,];
	scores <- sind$x[1];
	n <- 1;

	for (i in 2:nrow(index)) {
		if (pairssorted[i,1] %in% kTSPs == FALSE && pairssorted[i,2] %in% kTSPs==FALSE) {
			kTSPs <- rbind(kTSPs, pairssorted[i,]);
			scores <- rbind(scores,sind$x[i]);
			n <- n + 1;

			if (n >= k) {
				break;
			}
		}
	}

	return(list(index=kTSPs, scores=scores));

}


